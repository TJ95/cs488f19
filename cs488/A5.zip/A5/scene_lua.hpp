// Fall 2019

#pragma once

#include <string>

bool run_lua( const std::string& filename );
