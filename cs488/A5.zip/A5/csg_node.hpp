#pragma once

#include <list>
#include <memory>
#include "Primitive.hpp"
#include "Mesh.hpp"
#include "Material.hpp"
#include "GeometryNode.hpp"