// Fall 2019

#include "Material.hpp"

Material::Material()
{}

Material::~Material()
{}
